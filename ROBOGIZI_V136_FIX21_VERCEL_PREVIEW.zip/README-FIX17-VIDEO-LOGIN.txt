ROBOGIZI V136 FIX17 — VIDEO ANIMASI DI HALAMAN LOGIN

Perubahan:
- Mengganti logo rusak di atas judul ROBOGIZI pada halaman login dengan video robot yang diberikan pengguna.
- Video menggunakan autoplay, muted, loop, playsinline agar berjalan otomatis tanpa suara dan berulang di browser ponsel.
- File disimpan sebagai robogizi-login.mp4 dan ditambahkan ke app shell service worker untuk cache/offline.
- Nama cache service worker diperbarui agar browser mengambil app shell baru.
- Bagian dashboard, konfigurasi login Google, Firebase, Firestore, dan Cloudflare D1 tidak sengaja diubah.

Pemeriksaan:
- Sintaks JavaScript inline dan service worker diperiksa.
- Integritas ZIP diperiksa.
- Belum ada uji runtime langsung pada Netlify/perangkat; uji pada preview terlebih dahulu.
