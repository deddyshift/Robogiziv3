ROBOGIZI V136 FIX10 — PENGIKATAN EVENT DINAMIS

Perubahan:
- Menambahkan event delegation pada document untuk tombol #rgAddMenuList, #rgGiziExportWord, dan #rgGiziExportExcel.
- Handler menangkap klik sebelum handler tombol lain sehingga aksi tidak terduplikasi bila tombol kebetulan sudah terikat langsung.
- Saat Tambah Daftar Menu diklik, daftar baru dibuat, disimpan melalui alur yang sudah tersedia, lalu dashboard/monitoring dirender ulang.
- Tombol Word dan Excel memanggil downloadReport('word') dan downloadReport('excel'), dengan pesan kesalahan bila proses gagal.
- Tidak mengubah Firebase project ID, firestore.rules, Cloudflare D1, atau konfigurasi autentikasi.

Pemeriksaan lokal:
- Jalankan pemeriksaan sintaks semua blok JavaScript inline.
- Periksa integritas ZIP.
- Ini masih pemeriksaan kode statis; klik nyata setelah login Google, persistensi Firestore, serta sinkronisasi antarperangkat harus diuji pada staging sebelum produksi.
- Ekspor yang ada masih berformat .doc dan .xls kompatibel Office, bukan .docx/.xlsx native.
