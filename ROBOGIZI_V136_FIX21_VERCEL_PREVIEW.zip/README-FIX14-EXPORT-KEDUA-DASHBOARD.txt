ROBOGIZI V136 FIX14 — EKSPOR EXCEL/WORD PADA KEDUA DASHBOARD

Masalah yang dilaporkan:
Hasil ekspor di aplikasi spreadsheet menampilkan kode HTML (<!DOCTYPE>, <style>, <div>) sebagai teks.

Perbaikan:
- Ekspor Excel menghasilkan CSV terstruktur dari laporan (bukan HTML yang diberi ekstensi .xls).
- Ekspor Word tetap memakai dokumen HTML Office-compatible .doc.
- Menambahkan event delegation untuk tombol exportExcel/exportWord pada Dashboard Pemorsian dan rgGiziExportExcel/rgGiziExportWord pada Dashboard Pengawas Gizi, termasuk tombol yang muncul secara dinamis.
- Handler delegasi memanggil window.downloadReport agar akses fungsi konsisten.
- Tidak mengubah konfigurasi Firebase atau firestore.rules.

Validasi lokal:
- Semua blok JavaScript inline diperiksa sintaksnya.
- Integritas ZIP diperiksa.
Belum dilakukan klik langsung di browser setelah login. Uji di staging sebelum produksi.
Catatan: Excel yang dihasilkan adalah .csv (bukan .xlsx native); Word adalah .doc Office-compatible (bukan .docx native).
