ROBOGIZI V136 FIX16 — TOMBOL EKSPOR DI PANEL PREVIEW

Penyebab yang diperbaiki:
Tombol Word dan Excel dibuat saat preview dibuka, tetapi kode memasukkannya ke elemen header bagian luar, sedangkan tombol Tutup berada di dalam baris tombol anak. Operasi insertBefore tersebut bisa gagal sehingga tombol Word/Excel tidak muncul.

Perbaikan:
- Tombol “Simpan Word” dan “Simpan Excel” sekarang dimasukkan ke wadah tombol yang benar, berdampingan dengan tombol PDF dan Tutup.
- Handler unduhan menggunakan window.downloadReport untuk konsistensi cakupan fungsi.
- Tidak mengubah data aplikasi, project Firebase, firestore.rules, atau konfigurasi Cloudflare D1.
- Semua fungsi laporan lain dipertahankan.

Validasi lokal:
- Sintaks semua script inline.
- Integritas ZIP.
Belum diuji klik langsung di ponsel setelah login. Uji di pratinjau sebelum produksi.
