# ROBOGIZI V136 — Firebase Google Login & Persetujuan Developer

## Yang disiapkan dalam versi ini
- Login Google melalui Firebase Authentication.
- Pendaftar baru hanya dapat meminta dashboard **Tim Pemorsian** atau **Pengawas Gizi**.
- Profil pendaftar disimpan di Firestore `users/{uid}` dengan status `pending`.
- Developer `deddyshift@gmail.com` dapat menyetujui/menolak pendaftar dan menentukan dashboard final.
- Dashboard baru hanya dibuka untuk profil yang berstatus `approved` dan memiliki role yang diizinkan.
- Data lokal lama dibersihkan satu kali pada pemakaian pertama versi ini; database Cloudflare D1 tidak disentuh.
- Dashboard dan fungsi operasional yang sudah ada tetap berada dalam `index.html`.

## Langkah konfigurasi Firebase
1. Buka https://console.firebase.google.com/ dan pilih proyek `robogizi-app`.
2. Buka **Authentication → Sign-in method** dan pastikan **Google** aktif.
3. Buka **Authentication → Settings → Authorized domains**. Tambahkan domain tempat aplikasi di-host (misalnya domain Netlify yang benar-benar dipakai). Untuk pengujian lokal, tambahkan `localhost` bila diperlukan.
4. Buka **Firestore Database → Rules**.
5. Salin isi file `firestore.rules` ini ke editor Rules lalu tekan **Publish**.
6. Deploy folder aplikasi ke hosting HTTPS. Login Google tidak dapat diuji dengan andal saat halaman dibuka langsung sebagai `file://`.
7. Buka aplikasi dan masuk dengan akun Google `deddyshift@gmail.com`. Akun ini akan diberi profil developer pada login pertama.
8. Buka dashboard developer dan periksa antrean pada bagian **Persetujuan Pendaftaran**.

## Alur pendaftaran
1. Pengguna login menggunakan Google.
2. Jika belum mempunyai profil, pilih Tim Pemorsian atau Pengawas Gizi dan kirim pendaftaran.
3. Pendaftar menunggu di status `pending` dan belum dapat membuka dashboard.
4. Developer memilih dashboard final lalu menekan **Setujui**, atau menekan **Tolak**.
5. Pengguna perlu memeriksa status lagi atau login ulang untuk mengambil persetujuan terbaru.

## Catatan keamanan dan batasan
- `apiKey` pada Firebase Web config adalah identifier aplikasi web, bukan private key service account. Jangan pernah memasukkan private key service account ke HTML.
- Rules membatasi persetujuan dan pengubahan profil hanya untuk akun Google terverifikasi `deddyshift@gmail.com`.
- Semua koleksi selain `users` ditolak secara default oleh rules ini. Ini sengaja dilakukan agar tidak membuka database secara luas.
- Pada build ini Firestore dipakai untuk autentikasi profil dan alur persetujuan. Data operasional dashboard tetap memakai mekanisme penyimpanan lokal yang ada di aplikasi; sinkronisasi data operasional lintas perangkat belum diaktifkan.
- Reset data lokal dilakukan satu kali berdasarkan marker `robogizi_v136_empty_reset_done`. Untuk mengulang reset pada perangkat uji, hapus marker tersebut dari localStorage dan muat ulang. Ini tidak menghapus data di Firestore atau Cloudflare D1.
- Sebelum mengganti Firestore Rules yang sudah ada, simpan salinan rules sebelumnya. File rules ini menolak akses semua koleksi selain `users`.


Pengelolaan akun developer (versi perbaikan):
- Developer dapat Setujui, Tolak, atau Hapus akun ROBOGIZI dari panel.
- Tombol Hapus menghapus profil/akses pada Firestore `users`, bukan pengguna pada Firebase Authentication. Menghapus pengguna Authentication lain memerlukan Admin SDK pada backend tepercaya; jangan menyimpan service-account key di aplikasi web.
- Firestore Rules harus memberi developer terverifikasi izin read/update/delete pada `users`. Jangan membuat collection lain terbuka untuk semua pengguna.


## Sinkronisasi lintas perangkat (wajib)
Versi ini menyinkronkan data operasional melalui Firestore `sharedApp/main`. Setelah deploy, buka Firebase Console → Firestore Database → Rules, tempel isi `firestore.rules` dari ZIP ini, lalu Publish. Jangan menghapus koleksi `users` atau database D1 lama. Akun harus berstatus approved dengan role pemorsian/gizi/developer.
