ROBOGIZI V136 FIX13 — PERBAIKAN EKSPOR

Screenshot menunjukkan file .xls berisi source HTML (tag <!DOCTYPE>, <style>, <div>) sehingga tidak layak dibaca sebagai spreadsheet.

Perubahan:
- Excel: ekspor sekarang menghasilkan CSV berisi teks laporan, heading, dan tabel yang diekstrak dari HTML. File CSV dapat dibuka di Microsoft Excel/Google Sheets sebagai data baris-kolom; bukan file native .xlsx.
- Word: mempertahankan laporan berformat HTML Office-compatible dengan ekstensi .doc supaya isi dirender sebagai dokumen, bukan disamarkan sebagai Excel.
- Mempertahankan sumber data laporan unifiedReport dan alur tombol yang ada.

Validasi lokal:
- Pemeriksaan sintaks semua blok JavaScript inline.
- Pemeriksaan integritas ZIP.
Belum dilakukan pengujian klik langsung di browser ponsel atau membuka hasil di aplikasi Excel/Word. Uji di staging dahulu.
