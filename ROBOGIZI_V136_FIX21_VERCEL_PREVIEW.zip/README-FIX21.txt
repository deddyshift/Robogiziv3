ROBOGIZI V136 FIX21 — PERBAIKAN IKON SAVE HEADER DAN EKSPOR WORD/EXCEL

Perubahan:
1. Tombol simpan/pengaturan di header Pengawas Gizi membuka panel ekspor yang menampilkan PDF, Word, dan Excel. Panel ditampilkan dengan z-index lebih tinggi untuk menghindari tertutup elemen lain.
2. Pilihan Word dan Excel dari panel langsung memanggil fungsi unduhan yang sudah ada, bukan membuka preview yang dapat membuat pengguna mengira file sudah disimpan.
3. PDF tetap memakai fungsi preview PDF yang ada.
4. Tidak mengubah fungsi pembentuk laporan PDF, data, Firebase/Auth/Firestore, Cloudflare D1, atau service worker.

Format saat ini masih .doc kompatibel Word dan .csv untuk Excel, belum .docx/.xlsx asli.

Validasi lokal:
- Pemeriksaan sintaks seluruh script inline.
- Pemeriksaan integritas ZIP.
Belum dilakukan uji browser langsung atau uji unduhan di Netlify. Uji di Preview sebelum produksi.
