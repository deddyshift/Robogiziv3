ROBOGIZI V136 FIX12 — PERBAIKAN TOMBOL WORD/EXCEL

Bukti dari uji FIX11:
Tombol dashboard dirender dan delegasi klik ada, tetapi fungsi downloadReport berada di cakupan fungsi yang berbeda. Handler klik memanggil downloadReport sebagai nama lokal, sehingga dapat menghasilkan ReferenceError dan proses unduhan tidak berjalan.

Perubahan FIX12:
- Mengekspos fungsi laporan melalui window.downloadReport.
- Tombol Word/Excel pada delegasi klik memanggil window.downloadReport('word'/'excel').
- Fungsi pembuat laporan dan mekanisme Blob/unduhan yang sudah ada tetap digunakan.
- Tidak mengubah Firebase project ID atau firestore.rules.

Validasi lokal:
- Periksa sintaks semua blok JavaScript inline.
- Periksa integritas ZIP.
Belum dilakukan uji klik langsung setelah login Google atau pembukaan berkas di Word/Excel. Uji di staging sebelum produksi.
