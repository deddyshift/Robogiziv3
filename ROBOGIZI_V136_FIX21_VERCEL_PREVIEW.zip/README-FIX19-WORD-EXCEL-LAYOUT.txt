ROBOGIZI V136 FIX19 — PERAPIAN TAMPILAN EKSPOR WORD DAN EXCEL

Tujuan:
Memperbaiki kerapian file Word dan Excel tanpa mengubah tampilan Preview/PDF.

Perubahan:
- Word: mempertahankan struktur dan CSS laporan yang ada, lalu menerapkan aturan khusus ekspor untuk margin A4, judul, subjudul, tabel, lebar kolom, pembungkusan teks, dan pemisahan baris. Aturan ini hanya dipakai saat ekspor Word; buildReport/preview PDF tidak diubah.
- Excel: ekspor CSV sekarang menelusuri judul, paragraf, dan tabel sesuai urutan tampilannya, sehingga bagian laporan tidak dikelompokkan secara terpisah dan kehilangan konteks. Data tabel dipisahkan ke kolom.
- Tidak mengubah konfigurasi Firebase, Firestore, Cloudflare D1, login Google, video login, atau CSS PDF.

Format saat ini:
- Word: .doc kompatibel Office (HTML Office-compatible), belum .docx asli.
- Excel: .csv, belum .xlsx asli.

Validasi:
- Pemeriksaan sintaks JavaScript inline.
- Pemeriksaan integritas ZIP.
Belum ada uji langsung membuka file hasil ekspor di aplikasi Microsoft Word/Excel ponsel. Uji di Netlify Preview sebelum produksi.
