ROBOGIZI V136 - BUILD DIAGNOSIS STATUS SINKRONISASI

Tujuan perubahan:
- Menambahkan panel status sinkronisasi yang terlihat jika sebelumnya elemen rgCloudSyncStatus tidak ada.
- Menampilkan pesan awal apabila proses sinkronisasi belum bisa dimulai karena akun/role/Firestore belum siap.
- Tidak mengubah Firebase config, Firestore Rules, dokumen sharedApp/main, akun pengguna, atau database Cloudflare D1.
- Tidak menghapus localStorage atau data aplikasi.

Pemeriksaan lokal yang dilakukan:
- 27 blok script inline diperiksa menggunakan node --check; tidak ada kesalahan sintaks.
- ZIP diuji dengan unzip -t; tidak ada kerusakan arsip.

Batasan penting:
- Build ini belum diuji terhadap Firebase live atau dua HP secara end-to-end.
- Panel status membantu menampilkan pesan listener/write error yang sudah ditangani oleh kode. Panel tidak dengan sendirinya memperbaiki aturan Firebase atau menjamin sinkronisasi.
- Jangan gunakan tombol update manual atau melakukan perubahan data produksi sebagai tes pertama.

Uji aman setelah deploy:
1. Simpan ZIP lama sebagai cadangan dan jangan menghapus deploy lama.
2. Deploy ZIP ini ke Netlify sesuai alur deploy yang biasa dipakai.
3. Buka aplikasi, login dengan akun yang sudah approved, lalu lihat panel status.
4. Jika tertulis permission-denied, periksa Firestore Rules dan dokumen users/{UID}; jangan ubah data sharedApp/main.
5. Jika panel mengatakan terhubung tetapi data tidak lintas perangkat, kirim screenshot panel dari kedua HP dan waktu pengujiannya. Uji tulis dengan data contoh yang tidak penting hanya setelah memastikan cadangan data.
