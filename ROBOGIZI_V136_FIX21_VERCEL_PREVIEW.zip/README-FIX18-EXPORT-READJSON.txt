ROBOGIZI V136 FIX18 — PERBAIKAN readJson PADA EKSPOR WORD/EXCEL

Penyebab dari screenshot:
Ekspor Word dan Excel gagal dengan pesan “readJson is not defined”. Fungsi buildGiziReportSection memanggil helper readJson yang berada di lingkup JavaScript lain (IIFE), sehingga tidak tersedia saat laporan dirakit.

Perbaikan:
- Mengganti pemanggilan readJson yang tidak tersedia dengan helper readReportJson lokal yang membaca localStorage secara aman dan mencoba kunci cadangan *_backup jika diperlukan.
- Tombol Word dan Excel pada Dashboard Pengawas Gizi memanggil window.downloadReport secara konsisten dan menangkap pesan error.
- Mempertahankan paket FIX17 termasuk video login, Firebase config, Firestore rules, serta file dan alur aplikasi lain.

Validasi lokal:
- Pemeriksaan sintaks seluruh blok JavaScript inline.
- Pemeriksaan integritas ZIP.
- Pemeriksaan statis untuk memastikan pemanggilan readJson yang menyebabkan error sudah tidak ada pada builder laporan.

Batas pengujian:
Paket belum diuji secara interaktif melalui login Google dan browser Netlify pada perangkat pengguna. Uji di Netlify Preview sebelum produksi.
Format ekspor saat ini tetap mengikuti implementasi paket sumber: Word .doc Office-compatible dan Excel .csv; ini bukan file native .docx/.xlsx.
