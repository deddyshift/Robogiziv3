ROBOGIZI V136 FIX9 — PERBAIKAN TOMBOL MENU DAN EKSPOR WORD/EXCEL

Akar masalah yang ditemukan
1. Fungsi pengikat kontrol dashboard lama sempat diubah namanya, sedangkan pemanggilnya masih memakai nama bind(). Fungsi dari skrip lain juga pernah dipanggil lintas-cakupan JavaScript yang berbeda.
2. Form login versi lama sudah tidak memiliki beberapa elemen ID (rgLoginBtn, rgPass, rgRole, dan rgUser), tetapi binding lama mencoba mengaksesnya seolah-olah selalu ada. Error ini menghentikan fungsi sebelum handler Tambah Daftar Menu dipasang.

Perbaikan
1. Mengembalikan nama bind() di skrip pemilik kontrol dashboard lama agar cocok dengan pemanggil DOMContentLoaded.
2. Menghapus pemanggilan lintas-cakupan bindLegacyDashboardControls() dari skrip integrasi kedua.
3. Membuat pengikatan kontrol login lama aman: hanya memasang handler bila elemen terkait masih ada. Referensi elemen dalam pilihan role juga diperiksa sebelum digunakan. Dengan begitu elemen login lama yang sudah dihilangkan tidak menghentikan pemasangan handler dashboard.
4. Menjaga tombol Tambah Daftar Menu dan tombol Simpan Word/Excel beserta fungsi laporan yang telah tersedia.
5. Tidak mengubah Firebase project ID, firestore.rules, Cloudflare D1, dan aset konfigurasi lain.

Cara menguji pada staging sebelum mengganti deployment produksi
1. Unggah paket ke pratinjau/staging terlebih dahulu.
2. Masuk menggunakan akun Google Pengawas Gizi yang sudah disetujui.
3. Klik “Tambah Daftar Menu”; daftar baru harus muncul dan judul/isi dapat diedit.
4. Klik “Simpan Word” dan “Simpan Excel”; pastikan browser memulai unduhan.
5. Muat ulang halaman dan periksa apakah data menu/nilai gizi bertahan. Uji juga perangkat kedua untuk memastikan Firestore menerima dan membagikan pembaruan.

Pemeriksaan yang dilakukan pada paket ini
- 24 blok JavaScript inline lulus pemeriksaan sintaks Node.js.
- Pemeriksaan statis mengonfirmasi panggilan fungsi bind konsisten dan referensi login lama bersifat opsional.
- Tombol Tambah Daftar Menu, tombol ekspor, dan handler unduhan tetap ada.
- ZIP lolos pemeriksaan integritas.

Catatan batas pengujian
Saya belum dapat membuktikan klik nyata setelah login Google dan sinkronisasi lintas-perangkat di deployment dari lingkungan ini. Karena itu, uji paket ini di staging terlebih dahulu; jangan langsung mengganti produksi sebelum tombol dicoba pada akun Pengawas Gizi yang disetujui. Format ekspor saat ini adalah .doc dan .xls kompatibel Office, bukan .docx/.xlsx native.
