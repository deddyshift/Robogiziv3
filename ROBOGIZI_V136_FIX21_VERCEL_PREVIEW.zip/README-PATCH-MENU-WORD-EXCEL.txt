ROBOGIZI V136 FIX8 — AUDIT & PATCH MENU / WORD / EXCEL

Perubahan:
1. Memperbaiki fungsi binding dashboard. Sebelumnya ada dua deklarasi function bind() dalam satu lingkup; deklarasi terakhir menimpa handler tombol dashboard yang lebih awal. Handler dashboard lama sekarang dipanggil melalui bindLegacyDashboardControls().
2. Tombol Tambah Daftar Menu memakai fungsi addManualMenuList() aplikasi yang sudah ada, lalu menyimpan ke daftar bersama dan merender ulang dashboard Pengawas Gizi.
3. Menambah tombol Simpan Word dan Simpan Excel yang terlihat langsung pada kartu Preview Hasil Laporan Pengawas Gizi; tombol juga tetap disediakan di toolbar preview.
4. Penambahan item menu memastikan map informasi nilai gizi dan foto diinisialisasi berdasarkan ID daftar menu sehingga tiap daftar punya informasi nilai gizi tersendiri.
5. Menambahkan cadangan lokal untuk daftar menu. Kunci data utama tetap digunakan dan mekanisme sinkronisasi Firebase yang ada tidak dihapus.

Pemeriksaan otomatis:
- Arsip ZIP: diperiksa setelah dibuat.
- Sintaks JavaScript inline: 24 blok diperiksa; 0 error.
- Pemeriksaan statis: 11/11 kondisi terpenuhi.

Belum dapat dinyatakan teruji langsung:
- Klik/tambah daftar menu dalam browser sesudah login Google.
- Menutup aplikasi dan login ulang dengan data nyata.
- Sinkronisasi dua perangkat melalui Firestore.
- Membuka berkas hasil ekspor di Microsoft Word dan Excel.

Catatan format: ekspor saat ini membuat dokumen HTML kompatibel Office dengan ekstensi .doc dan .xls, bukan paket OOXML asli .docx/.xlsx. Tidak ada perubahan terhadap firestore.rules atau konfigurasi Firebase dalam patch ini.


Hasil pemeriksaan statis:
[LULUS] legacy handlers not shadowed
[LULUS] dashboard Word button visible
[LULUS] dashboard Excel button visible
[LULUS] Word button handler wired
[LULUS] Excel button handler wired
[LULUS] menu list uses established add function
[LULUS] per-list nutrition UI exists
[LULUS] shared menu persistence with backup
[LULUS] Word Excel export filenames
[LULUS] existing Firebase config preserved
[LULUS] Firestore rules file present

Kesalahan sintaks:
[]
