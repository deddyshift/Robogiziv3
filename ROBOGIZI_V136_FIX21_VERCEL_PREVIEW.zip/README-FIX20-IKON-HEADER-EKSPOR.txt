ROBOGIZI V136 FIX20 — IKON DISKET HEADER

Perbaikan:
- Ikon disket pada header Dashboard Pengawas Gizi sekarang membuka panel "Simpan / Ekspor", bukan langsung membuka preview PDF.
- Panel yang sudah ada menampilkan pilihan PDF, Excel, dan Microsoft Word.
- Pilihan tetap memakai handler ekspor yang sudah ada; perubahan hanya pada aksi ikon header.
- Fungsi Preview/PDF, CSS laporan, Firebase/Auth/Firestore, dan Cloudflare D1 tidak diubah.

Validasi lokal:
- Semua script inline diperiksa dengan node --check.
- Integritas ZIP diperiksa.
Belum diuji langsung di browser ponsel/Netlify; uji di Preview sebelum produksi.
