ROBOGIZI V136 FIX15 — IKON DISKET, TEMA BERSAMA, DAN PERSISTENSI

Perubahan UI:
- Ikon roda gigi pada header Pengawas Gizi diganti ikon disket.
- Klik ikon membuka Preview Laporan yang sudah tersedia; dari preview pengguna dapat memilih PDF/Word/Excel.
- Header Pengawas Gizi membaca logo, judul, subjudul, warna, tema header, dan gambar header dari pengaturan Pemorsian (mbg_pemorsian_settings_v1).
- Tema diterapkan saat startup, saat dashboard ditampilkan, saat storage berubah, dan setelah event rg:cloud-updated.

Data dan sinkronisasi:
- Mempertahankan jalur penyimpanan Firebase sharedApp/main dan SHARED_KEYS yang sudah ada, termasuk mbg_pemorsian_settings_v1.
- Tidak mengubah Firebase project ID, firestore.rules, maupun database Cloudflare D1.
- Kode saat ini menggunakan Firestore sharedApp/main untuk pengguna approved. Sinkronisasi lintas perangkat tetap perlu dites dengan dua akun approved yang memiliki akses ke SPPG/data yang sama; pemeriksaan sintaks saja tidak membuktikan sinkronisasi live atau mencegah seluruh konflik edit serentak.
- Tidak menghapus localStorage atau IndexedDB.

Validasi lokal:
- Sintaks semua blok JavaScript inline diperiksa.
- Integritas ZIP diperiksa.
- Belum dilakukan pengujian klik langsung, refresh, logout/login, maupun dua perangkat setelah deploy.

Ekspor: mengikuti implementasi FIX14 (Excel CSV, Word .doc Office-compatible, Preview/PDF menggunakan alur yang sudah tersedia). CSV bukan .xlsx native dan DOC bukan .docx native.
