ROBOGIZI V136 - GIZI DASHBOARD BUTTONS / PHOTOS / REPORT FIX

Perbaikan pada paket ini:
- Preview Laporan Pengawas Gizi memanggil laporan gabungan Pemorsian + Pengawas Gizi dan menampilkan pesan diagnostik jika gagal.
- Tombol tambah/hapus informasi nilai gizi memperbarui tampilan panel lama dan dashboard nilai gizi terintegrasi.
- Unggah foto Pengawas Gizi membaca foto, mengecilkan resolusi/ukuran, menyimpan ke penyimpanan lokal aplikasi, lalu memperbarui tampilan. Maksimal 6 foto pada panel umum.
- Menambahkan tombol Hapus Catatan Menu Hari Ini dengan konfirmasi.
- Tombol Tambah Daftar Menu menyegarkan tampilan daftar menu terintegrasi.
- Pesan sukses/gagal aksi tidak lagi mengganti seluruh isi kartu dashboard.
- Service worker cache version diperbarui agar versi baru dimuat setelah deployment.

Pemasangan:
1. Ekstrak ZIP.
2. Deploy seluruh isi folder (index.html dan semua aset) ke situs Netlify yang sama.
3. Setelah deploy selesai, buka URL situs, lakukan reload paksa atau tutup tab dan buka ulang.
4. Login dengan Google, buka Dashboard Pengawas Gizi, lalu uji tambah nilai gizi, tambah/hapus foto, catatan, preview laporan, dan ekspor/cetak.

Batas verifikasi:
- Pemeriksaan sintaks JavaScript inline dilakukan pada semua skrip di index.html.
- Fungsi Firebase dan interaksi browser HP tidak dapat dinyatakan lulus sebelum diuji pada situs setelah deploy.
- Tidak mengubah Firestore Rules, Firebase Authentication, konfigurasi Firebase, atau database Cloudflare D1 lama.
- Tidak menghapus dashboard atau data yang sudah tersimpan; data operasional baru tetap mengikuti penyimpanan aplikasi yang digunakan.


PATCH UJI 2026-10-11:
- Pilihan zat gizi melalui datalist: energi, makronutrien, vitamin, mineral, asam lemak, air dan serat.
- Satuan diperluas (SI dan label gizi umum).
- Perbaikan fokus keyboard: input zat gizi/nilai tidak membangun ulang seluruh form saat mengetik; preview diperbarui tanpa kehilangan fokus.
- Runtime login Firebase dan seluruh tombol belum bisa dinyatakan lolos tanpa uji langsung pada deployment.
