ROBOGIZI V136 — AUDIT AWAL DAN PERBAIKAN STARTUP AMAN

PERBAIKAN YANG DITERAPKAN
1. Menghapus reset otomatis saat aplikasi pertama kali dibuka yang sebelumnya menghapus hampir semua localStorage.
2. Menghapus pemanggilan indexedDB.deleteDatabase('MBG_Pemorsian_DB') yang dapat menghapus data operasional lama di browser.
3. Startup sekarang tidak menghapus data secara otomatis. Pembersihan data operasional harus menjadi tindakan eksplisit yang terkonfirmasi dan berizin.
4. Tidak ada koneksi/perintah untuk mengubah atau menghapus database Cloudflare D1 lama dalam perubahan ini.
5. Semua file dashboard dan aset dari paket sumber dipertahankan; perubahan fungsional hanya pada skrip startup yang berbahaya.

HASIL PEMERIKSAAN STATIS
- 24 skrip inline diperiksa dengan `node --check`: tidak ditemukan kesalahan sintaks.
- Tidak ditemukan lagi localStorage.clear() atau indexedDB.deleteDatabase() pada index.html.
- Pemeriksaan sintaks tidak membuktikan bahwa semua tombol berhasil bekerja di browser atau semua akses data benar.

STATUS YANG BELUM BOLEH DIANGGAP LULUS
- Sinkronisasi daftar menu Pengawas Gizi ke akun/perangkat Pemorsian lain: belum dibuktikan. Bagian tertentu memakai localStorage/state lokal.
- Sinkronisasi foto dan informasi gizi antar akun/perangkat: belum dibuktikan.
- Preview/unduh laporan di browser Android: perlu uji langsung pada situs setelah deploy.
- Seluruh tombol setiap dashboard: belum bisa dinyatakan lulus tanpa pengujian interaksi end-to-end.
- Firestore Rules dalam paket saat ini secara default menolak koleksi selain users. Jangan menganggap Firestore sebagai penyimpanan operasional lintas dashboard sampai skema dan Rules yang sesuai dirancang dan diuji.
- Firebase Authentication, antrean persetujuan, tolak/hapus akun, dan logout harus dites dengan akun developer, pemorsian, gizi, dan akun pending terpisah.

PENTING TENTANG DATA AWAL KOSONG
Perbaikan ini sengaja tidak menghapus data yang sudah ada secara otomatis. Karena itu, jika browser pernah menyimpan data lama, data tersebut mungkin tetap muncul. Untuk memulai data operasional kosong, lakukan reset hanya melalui prosedur reset eksplisit yang terverifikasi dan tidak menyentuh konfigurasi akun, Firebase, atau database Cloudflare D1 lama. Jangan hapus data browser sebelum memastikan data yang ingin dipertahankan.

CARA DEPLOY
1. Simpan ZIP asli sebagai cadangan.
2. Ekstrak seluruh isi ROBOGIZI_V136_AUDIT_SAFE_STARTUP.zip.
3. Upload/deploy seluruh isi folder (termasuk index.html, aset, manifest, service worker, _headers, dan netlify.toml) ke situs Netlify yang digunakan.
4. Setelah deploy, tutup tab situs lalu buka lagi. Jika masih melihat versi lama, lakukan clear cache situs/service worker saja; jangan menghapus data situs/storage kecuali sudah dipastikan aman.
5. Jalankan checklist pada README-UJI-FUNGSI.txt dan catat hasil setiap peran.

JANGAN MENGGANTI FIRESTORE RULES SECARA MEMBABI BUTA
Rules dalam ZIP tidak membuka akses untuk koleksi operasional. Sebelum sinkronisasi cloud dibuat, tentukan skema koleksi dan otoritas per role; kemudian uji baca/tulis dengan akun masing-masing. Jangan mengubah database Cloudflare D1 lama.


PEMBARUAN AUDIT 12-10-2026
- Perbaikan scroll responsif: menambahkan aturan scroll sentuh Android pada panel/layar panjang dan memastikan body kembali dapat discroll saat splash/pengaturan tidak mengunci layar. Kunci scroll saat startup dan pengaturan tetap dipertahankan.
- Perbaikan konflik sinkronisasi saat mengetik: snapshot Firestore yang datang ketika fokus berada di input/select/textarea/contenteditable kini ditunda sebelum mengubah state maupun localStorage. Snapshot terbaru diterapkan setelah pengguna keluar dari seluruh kontrol, sehingga risiko input yang sedang diketik tertimpa pembaruan realtime berkurang.
- Cache service worker dinaikkan ke robogizi-v136-repair-audit-20261012a agar perubahan aset dikenali sebagai versi baru.
- Tidak mengubah Firestore Rules, konfigurasi Firebase, maupun database Cloudflare D1.
- Validasi statis ulang dilakukan pada paket hasil koreksi. Validasi statis bukan pengganti uji browser Android, uji dua akun/perangkat, atau pengujian otorisasi Firestore di project aktif. Jangan menyebut aplikasi bebas seluruh bug sebelum uji end-to-end tersebut lulus.


PATCH SINKRONISASI ANTAR-PERANGKAT (12 OKT 2026)
- Memastikan sharedApp/main diinisialisasi dengan transaksi jika dokumen belum ada atau kosong.
- Memperluas daftar kunci bersama ke catatan khusus dan laporan sisa menu.
- Status UI membedakan proses menghubungkan, tersambung, berhasil menulis, dan gagal menulis.
- Cache PWA dinaikkan ke robogizi-v136-shared-sync-fix-20261012c.
- Ini belum menggantikan pengujian live dua perangkat; Firebase project dan Firestore Rules harus sesuai dengan proyek yang dipilih.

PATCH LANJUTAN 13-10-2026 (AMAN, TANPA MIGRASI DATABASE)
- Memperbaiki sumber pengaturan judul laporan dan subjudul laporan: generator laporan sekarang membaca `mbg_pemorsian_settings_v1` (kunci aktif pada panel Pengaturan Tampilan), dengan fallback ke kunci lama `mbg_tampilan_pengguna_v1`.
- Nama file laporan dan judul laporan sekarang mengambil `reportTitle` dari pengaturan aktif, bukan hanya nilai default.
- Tidak mengubah Firebase config, Firestore Rules, skema Firestore, Cloudflare D1, autentikasi, atau data pengguna.
- Validasi sintaks ulang: 24 skrip JavaScript inline diperiksa dengan `node --check`; 0 kesalahan sintaks.
- Batasan: ini perbaikan terarah untuk judul/subjudul laporan. Riwayat laporan lintas perangkat, ekspor XLS/DOC dalam format native, serta pengujian browser dua akun/perangkat masih perlu dikerjakan dan diverifikasi sebelum deployment.
