ROBOGIZI V136 FIX11 — PERBAIKAN CAKUPAN FUNGSI

Berdasarkan screenshot FIX10, klik Tambah Daftar Menu menghasilkan:
“renderGiziIntegrated is not defined”.
Penyebabnya fungsi berada dalam cakupan JavaScript berbeda dari handler klik. FIX11 mengekspos fungsi render yang diperlukan melalui window agar handler dapat memanggilnya, termasuk renderMonitoring dan addManualMenuList.

Pemeriksaan:
- Sintaks JavaScript inline diuji dengan Node.
- Integritas ZIP diuji.
- Belum dilakukan uji klik langsung setelah login Google, penyimpanan Firestore, ekspor di perangkat, atau sinkronisasi multi-perangkat. Uji di staging sebelum produksi.
- Tidak mengubah konfigurasi project Firebase atau aturan Firestore.
